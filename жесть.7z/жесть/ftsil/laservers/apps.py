from django.apps import AppConfig


class LaserversConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'laservers'
